# Station Network Analysis Package

This is an analysis/export package generated from the supplied 78-file filtered WIMT asset archive. It is **not** an independent open-data railway network and is not cleared for public redistribution. Read `docs/ANALYSIS_REPORT.md` and `docs/DATA_DICTIONARY.md` first.

The graph intentionally contains station nodes only and zero verified edges because the source Graph table is empty. Candidate references are kept separately and clearly marked unverified.
