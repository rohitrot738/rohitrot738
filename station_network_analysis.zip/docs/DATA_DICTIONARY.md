# Data Dictionary

## stations.csv (`station_info`)
- `station_code`: source station code; unique within this table.
- `title`: source station display name.
- `gid`: source-specific identifier stored as text; do not assume it is globally stable.
- `pop`: source popularity/ranking value; meaning/scale not documented here.
- `lat`, `lng`: source latitude/longitude.
- `uber_available`: source boolean-like flag; not railway topology.
- `title_soundex`, `title_soundex_index`: source search/matching fields.
- `wifi_station`: source flag; not railway topology.
- `city`: source city label, often blank.
- `lines`: comma-separated source tokens; semantics are not documented, not verified physical track IDs.
- `place_id`: external place identifier.

## station_aliases.csv (`station_aka_info`)
- `station_code`: station code to which an alias belongs.
- `title`: alternate station name.
- `pop`: source popularity value.

## station_localities.csv (`station_locality`)
- `station_code`: station code.
- `locality_place_id`: external locality/place identifier.
- `locality_name`: locality label.
- `tier`: source locality tier; exact semantics not documented.

## platform_directions.csv (`platform_direction`)
- `station_code`: station with the platform record.
- `platform_number`: platform identifier as stored by source.
- `prev_station`, `next_station`: previous/next station references from source; candidate adjacency only.
- `direction`: source label (`Left`, `Right`, or `Both` in observed rows); interpretation is source-specific.

## schedule_station_catalog.csv (`schedule.db.Station`)
- `id`: schedule database internal station ID.
- `code`: source code, may use internal naming conventions.
- `lat`, `lng`: coordinates.
- `popularity`, `type_id`, `city`, `place_id`, `cluster_id`: source-specific fields.
- `metadata`: raw blob represented as hexadecimal; not decoded.

## schedule_station_names.csv (`schedule.db.StationName`)
- `station_id`: internal ID linked conceptually to `Station.id`.
- `name`: station name.
- `lang`: source language ID; all observed rows are 0.
- `name_type`, `soundex`, `soundex_index`: source-specific name/search fields.

## Derived files
- `station_line_tags.csv`: one row per token split from `stations.csv.lines`. `verification_status` is always unverified.
- `station_connection_candidates.csv`: each non-empty previous/next reference is exported as a candidate from a station to another station. This is not a confirmed track edge.
- `interchange_candidates.csv`: stations with more than one raw line token; these are not verified junctions.
- `track_graph.json`: only station nodes are included; verified edge list is empty.

Empty `railway_tracks.csv`, `junctions.csv`, `branch_lines.csv`, and `railway_routes.csv` are schema placeholders, not evidence that no such infrastructure exists in reality; only that it is not present in the inspected source tables.
