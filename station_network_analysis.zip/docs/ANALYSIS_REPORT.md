# Railway Network Data Analysis Report

## Executive finding
The supplied source is `whereismytrain_assets_filtered_v2.zip` (78 files), a **filtered Where Is My Train APK asset archive**, not a clean/open railway GIS dataset. It contains a useful station catalogue and some station/platform reference data, but it does **not** contain a populated track graph in the inspected SQLite database. Therefore this package can support station lookup and preliminary candidate-link analysis; it cannot, by itself, establish a complete physical track network, branch-line topology, train timetable, or live train position.

## Verified source facts
- App data version: `7.3.1`.
- `whereismytrain.db.station_info`: 10,083 rows; station codes are unique in this table.
- `station_aka_info`: 789 alternate-name rows across 695 station codes.
- `station_locality`: 10,050 rows.
- `platform_direction`: 351 platform-direction rows covering 114 station codes.
- `schedule.db.Station` and `StationName`: 822 rows each.
- `schedule.db.Graph`: 0 rows; `StationCluster`, `NoPathTriplets`, and `FromToSuggestions` are also empty.
- 718 station records have a non-empty city field; 718 have a non-empty raw `lines` field.
- The raw `lines` field yields 870 comma-separated tokens. Their semantics are not documented in the database, so they are exported as raw tokens, not treated as authoritative track IDs.
- 108 stations have multiple raw line tokens; these are only *interchange candidates*, not verified railway junctions.
- `platform_direction` yields 678 previous/next station references. 650 have both station codes present in `station_info`; these remain unverified candidate links, not confirmed physical track edges.

## Important source limitation
The source archive's own README says train-number/name lookup tables and some train-history/alarm records were removed from this filtered archive. The route graph table is present structurally but empty. Some binary assets (`boondi`, `munthiri`, `frodo`, `mankatha`, etc.) are not decoded here because their schemas are not supplied and their contents cannot safely be interpreted from names or bytes alone. Their file sizes and paths are listed in `metadata/source_asset_inventory.csv`.

## Dataset contents
- `data/stations.csv`: station master from `station_info`.
- `data/station_aliases.csv`: alternate names.
- `data/station_localities.csv`: locality/place references.
- `data/platform_directions.csv`: platform, previous/next references, direction.
- `data/schedule_station_catalog.csv` and `schedule_station_names.csv`: separate 822-row schedule station catalogue and names.
- `data/station_line_tags.csv`: raw tokens split from `station_info.lines`; semantics unverified.
- `data/station_connection_candidates.csv`: candidate links from platform previous/next references; not verified track edges.
- `data/interchange_candidates.csv`: stations with multiple raw line tokens; not confirmed junctions.
- `data/track_graph.json`: station nodes only; verified edges intentionally empty.
- `railway_tracks.csv`, `junctions.csv`, `branch_lines.csv`, `railway_routes.csv`: empty schema files because source-backed records were not found.

## Data model and interpretation
1. **Station catalogue** is present and usable for station search and map pins, subject to validation.
2. **Physical track network** is not established. Geographic proximity is not proof of a rail connection.
3. **Junctions/branch lines** cannot be authoritatively identified from the current data. Multi-line station tokens are only candidates.
4. **Timetable/train routes** are not present in the exported relational tables. Train route sequences require a separate valid source.
5. **Live tracking** requires a live location feed or GPS/cell-based observations and is not provided by this station catalogue.

## Rights and redistribution warning
This archive was extracted from a Where Is My Train Android application. Removing app branding or changing filenames does not grant ownership or redistribution rights. The bundled `source_open_source_licenses.html` covers listed third-party packages; it does not automatically license the app's station database or all data. Treat these exports as a private analysis copy unless the relevant data rights and permissions are independently confirmed. Do not publish or commercially redistribute this package on the assumption that the bundled third-party notices grant permission.

## Recommended next data needed
To build a trustworthy railway network, add an independently licensed railway GIS source containing track geometries and station/track relations (for example, OpenStreetMap data under ODbL with required attribution), then reconcile station identifiers. Obtain timetable/route sequences and live location data from separately authorized sources. Keep physical infrastructure, scheduled service, and live train position as separate layers.
