
�
Explore Patna*Find Popular Temples, Ghats, Hotels & more�

Nearby AttractionsExplore nearby attractions�
Gandhi MaidanChIJBSS1jllY7TkRzuXcw2oZbX8uhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJBSS1jllY7TkRzuXcw2oZbX8&entry=wimt_gmm_explore �
Sanjay Gandhi Biological ParkChIJIRqU-_NX7TkRFJo8lXnIq_Yuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJIRqU-_NX7TkRFJo8lXnIq_Y&entry=wimt_gmm_explore �
	Patna ZooChIJlejRAwNX7TkRCtSdI0HE-5ouhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJlejRAwNX7TkRCtSdI0HE-5o&entry=wimt_gmm_explore �
Buddha Smriti ParkChIJ8akolUJY7TkRojL6_2IsxX0uhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ8akolUJY7TkRojL6_2IsxX0&entry=wimt_gmm_explore �
ISKCON Temple PatnaChIJC_YJbe1Y7TkRp8BDZvrnvwIuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJC_YJbe1Y7TkRp8BDZvrnvwI&entry=wimt_gmm_explore �
GolgharChIJ8-h4SVBY7TkRzebQ51rRjAEuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ8-h4SVBY7TkRzebQ51rRjAE&entry=wimt_gmm_explore �
Bihar MuseumChIJwdyPyz1Y7TkROpvzzSOHi30uhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJwdyPyz1Y7TkROpvzzSOHi30&entry=wimt_gmm_explore "Ahttps://storage.googleapis.com/wimt/events/thumbnails/temples.png(�
Nearby TransportExplore nearby Transport�
Patna Junction railway stationChIJ86aXgmhY7TkRS__VL8hYJXsuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ86aXgmhY7TkRS__VL8hYJXs&entry=wimt_gmm_explore �
/Jayprakash Narayan International Airport, PatnaChIJVTWh0OdX7TkR1QcP-S7TAQkuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJVTWh0OdX7TkR1QcP-S7TAQk&entry=wimt_gmm_explore �
Danapur railway stationChIJK5DaC_NX7TkR6_sOqLXWKoUuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJK5DaC_NX7TkR6_sOqLXWKoU&entry=wimt_gmm_explore �
Patliputra StationChIJ07q89atX7TkRjhz6JA2rmwYuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ07q89atX7TkRjhz6JA2rmwY&entry=wimt_gmm_explore �
Bairiya Bus StandChIJd_vMCACn8jkRCNAxGpvvVEkuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJd_vMCACn8jkRCNAxGpvvVEk&entry=wimt_gmm_explore "Chttps://storage.googleapis.com/wimt/events/thumbnails/transport.png(�
Nearby Medical CentreExplore nearby Medical Centre�
2Jay Prabha Medanta Super Specialty Hospital, PatnaChIJjbGB3w9Z7TkRhZJHmBj0o6Euhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJjbGB3w9Z7TkRhZJHmBj0o6E&entry=wimt_gmm_explore �
bPrakriti Sex and Gender Clinicc- Best Sexologist In Patna | Best Sexual Health Specialist In PatnaChIJzegKM_hZ7TkR5W8geOnHZ1Euhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJzegKM_hZ7TkR5W8geOnHZ1E&entry=wimt_gmm_explore �
.Patna Medical College & Hospital (PMCH), PatnaChIJh0yeRNBZ7TkRh7yUDxEeuQwuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJh0yeRNBZ7TkRh7yUDxEeuQw&entry=wimt_gmm_explore "Chttps://storage.googleapis.com/wimt/events/thumbnails/emergency.png(�
Nearby HotelsExplore nearby Hotels�
VijayaTej Clarks Inn, PatnaChIJrxqsBn5X7TkR0F13pi8z0gsuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJrxqsBn5X7TkR0F13pi8z0gs&entry=wimt_gmm_explore �
HOTEL PATLIPUTRA CONTINENTALChIJ2bpmS-NX7TkRrdAT5vevdb4uhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ2bpmS-NX7TkRrdAT5vevdb4&entry=wimt_gmm_explore �
Hotel The PanacheChIJTznenllY7TkRljm2PbkJM4kuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJTznenllY7TkRljm2PbkJM4k&entry=wimt_gmm_explore �
Hotel MauryaChIJVVVV1ldY7TkRtc5ZMB966KUuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJVVVV1ldY7TkRtc5ZMB966KU&entry=wimt_gmm_explore "@https://storage.googleapis.com/wimt/events/thumbnails/hotels.png("Dhttps://storage.googleapis.com/wimt/explore/images/explore_patna.pngv1pnbe_v1 (�