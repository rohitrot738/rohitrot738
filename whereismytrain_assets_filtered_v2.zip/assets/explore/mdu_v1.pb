
�!
Explore Madurai*Find Popular Temples, Ghats, Hotels & more�
Visit TempleExplore nearby Temples�
Meenakshi Amman TempleChIJh2nkYYTFADsRA2co5RxiNPEuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJh2nkYYTFADsRA2co5RxiNPE&entry=wimt_gmm_explore �
Arulmigu Koodal Azhagar TempleChIJUZYrS4DFADsRZgiZpxfy9-ouhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJUZYrS4DFADsRZgiZpxfy9-o&entry=wimt_gmm_explore �
Kothanda Ramar TempleChIJlRcyXujiATsRCn11gysx8VMuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJlRcyXujiATsRCn11gysx8VM&entry=wimt_gmm_explore �
%Arulmigu Sri Pandi Muneeswaran TempleChIJe-Qw0EfEADsRY9YE0z3oM3Iuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJe-Qw0EfEADsRY9YE0z3oM3I&entry=wimt_gmm_explore �
*Arulmigu Immaiyilum Nanmai Tharuvar TempleChIJ54x0C4HFADsRFFK2m9pDm_0uhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ54x0C4HFADsRFFK2m9pDm_0&entry=wimt_gmm_explore "Ahttps://storage.googleapis.com/wimt/events/thumbnails/temples.png(�
Nearby TransportExplore nearby Transport�
Madurai AirportChIJFSAYuGnQADsRF3_75hRYz5Auhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJFSAYuGnQADsRF3_75hRYz5A&entry=wimt_gmm_explore �
Madurai JunctionChIJK1Cphn3PADsRNuMSiva4s1cuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJK1Cphn3PADsRNuMSiva4s1c&entry=wimt_gmm_explore �
Madurai Railway StationChIJmxorkCrFADsRMC3C8EpucrEuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJmxorkCrFADsRMC3C8EpucrE&entry=wimt_gmm_explore �
Mattuthavani Omni Bus StandChIJ-2cqvzLEADsR95sg4mvcjAQuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ-2cqvzLEADsR95sg4mvcjAQ&entry=wimt_gmm_explore �
M.G.R. Bus standChIJ5VOcOybFADsR_RcESbZ6mAAuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ5VOcOybFADsR_RcESbZ6mAA&entry=wimt_gmm_explore "Chttps://storage.googleapis.com/wimt/events/thumbnails/transport.png(�
Nearby Medical CentreExplore nearby Medical Centre�
Aravind Eye Hospital - MaduraiChIJq8bb50PFADsR2Le-OwdYmsAuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJq8bb50PFADsR2Le-OwdYmsA&entry=wimt_gmm_explore �
#Apollo Speciality Hospitals MaduraiChIJ6xBiprHFADsRtEr7A2qYAkcuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ6xBiprHFADsRtEr7A2qYAkc&entry=wimt_gmm_explore �
,Meenakshi Mission Hospital & Research CentreChIJdyGxBi7EADsRxHFT9W8m-qIuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJdyGxBi7EADsRxHFT9W8m-qI&entry=wimt_gmm_explore �
lHannah Joseph Hospital - Neurology and Neurosurgery Hospital | Top Neurosurgeons & Spine Surgeons in MaduraiChIJZ52yLbHFADsRuWMiHMtsoAcuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJZ52yLbHFADsRuWMiHMtsoAc&entry=wimt_gmm_explore �
Govt Rajaji HospitalChIJLYIg6pbFADsRC8oCqX7L1Hsuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJLYIg6pbFADsRC8oCqX7L1Hs&entry=wimt_gmm_explore "Chttps://storage.googleapis.com/wimt/events/thumbnails/emergency.png(�
Nearby HotelsExplore nearby Hotels�
Hotel VijayChIJXbwaQYDFADsRjHXkX92j4bYuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJXbwaQYDFADsRjHXkX92j4bY&entry=wimt_gmm_explore �
Regency Madurai by GRT HotelsChIJp4Pd1wrPADsRZ46sFh2xyNcuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJp4Pd1wrPADsRZ46sFh2xyNc&entry=wimt_gmm_explore �
Heritage MaduraiChIJG9kUlj_PADsRfpk7dudDOnguhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJG9kUlj_PADsRfpk7dudDOng&entry=wimt_gmm_explore �
Hotel SupremeChIJhUS6dIfFADsR6QNqZJ1JR88uhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJhUS6dIfFADsR6QNqZJ1JR88&entry=wimt_gmm_explore �
Hotel Royal CourtChIJVwr8c4fFADsRlqfdKaZbtNYuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJVwr8c4fFADsRlqfdKaZbtNY&entry=wimt_gmm_explore "@https://storage.googleapis.com/wimt/events/thumbnails/hotels.png("Fhttps://storage.googleapis.com/wimt/explore/images/explore_madurai.pngv1mdu_v1 (�