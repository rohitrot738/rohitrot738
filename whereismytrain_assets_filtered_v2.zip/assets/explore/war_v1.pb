
�!
Explore Warangal*Find Popular Temples, Ghats, Hotels & more�
Nearby AttractionsExplore nearby attractions�
Warangal FortChIJ46_LbS1bMzoRxKEu2sSLpZcuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ46_LbS1bMzoRxKEu2sSLpZc&entry=wimt_gmm_explore �
Sri Bhadrakali DevastanamChIJISxoK3NFMzoRjJzLA7seKF0uhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJISxoK3NFMzoRjJzLA7seKF0&entry=wimt_gmm_explore �
Bhadrakali Temple ParkChIJJeeCf3NFMzoRtb1Zx4Jbk4guhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJJeeCf3NFMzoRtb1Zx4Jbk4g&entry=wimt_gmm_explore �
Kakatiya Musical GardenChIJ610O8RFFMzoRbENfIss5gzouhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ610O8RFFMzoRbENfIss5gzo&entry=wimt_gmm_explore �
Narasimha Swamy TempleChIJ6byxuQ1FMzoReLMHAG_452Quhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ6byxuQ1FMzoReLMHAG_452Q&entry=wimt_gmm_explore "Ahttps://storage.googleapis.com/wimt/events/thumbnails/temples.png(�
Nearby TransportExplore nearby Transport�
Warangal Railway StationChIJ7UovfoZFMzoR_1t317tBJ_4uhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ7UovfoZFMzoR_1t317tBJ_4&entry=wimt_gmm_explore �
WarangalChIJ9ayondhEMzoR40Is-jUKclYuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ9ayondhEMzoR40Is-jUKclY&entry=wimt_gmm_explore �
Warangal District Bus StandChIJqReVPjJFMzoRHPGPKr9h6GIuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJqReVPjJFMzoRHPGPKr9h6GI&entry=wimt_gmm_explore �
Airstrip of MamnoorChIJf4-2lPtaMzoRDjYNog-U2tEuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJf4-2lPtaMzoRDjYNog-U2tE&entry=wimt_gmm_explore �
Mamnoor Airport, warangalChIJx6QZJwBbMzoRwNbTNLM5zTAuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJx6QZJwBbMzoRwNbTNLM5zTA&entry=wimt_gmm_explore "Chttps://storage.googleapis.com/wimt/events/thumbnails/transport.png(�
Nearby Medical CentreExplore nearby Medical Centre�
MedPlus Shambunipet WarangalChIJnVma9fdbMzoR2m-P2p_1tTouhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJnVma9fdbMzoR2m-P2p_1tTo&entry=wimt_gmm_explore �
MedPlus Svn Road WarangalChIJp0th9xpFMzoR8oqV4rwCufguhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJp0th9xpFMzoR8oqV4rwCufg&entry=wimt_gmm_explore �
MedPlus Station Road WarangalChIJ9Ryl1aZFMzoROxHs1CZzH54uhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJ9Ryl1aZFMzoROxHs1CZzH54&entry=wimt_gmm_explore �
MedPlus Kothawada Warangal ExpChIJp9dVZAJFMzoRRlx2Okp-aQAuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJp9dVZAJFMzoRRlx2Okp-aQA&entry=wimt_gmm_explore �
'Medplus Bommalagudi Road Kareemabad ExpChIJwYfJvHxFMzoR_l78cOml1YUuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJwYfJvHxFMzoR_l78cOml1YU&entry=wimt_gmm_explore "Chttps://storage.googleapis.com/wimt/events/thumbnails/emergency.png(�
Nearby HotelsExplore nearby Hotels�
Hotel Grand Gayathri WarangalChIJA-TlKydFMzoRssonL21AQsguhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJA-TlKydFMzoRssonL21AQsg&entry=wimt_gmm_explore �
Hotel RatnaChIJMapCDRxFMzoRuhgn1VO1qzsuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJMapCDRxFMzoRuhgn1VO1qzs&entry=wimt_gmm_explore �
WHotel Sahasra DLA AC Convention Hall | AC Banquet Hall | AC Rooms | Zamindar RestaurantChIJt4Dr1WhFMzoRus9FnV0vdxYuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJt4Dr1WhFMzoRus9FnV0vdxY&entry=wimt_gmm_explore �
%Super Collection O Bommarilu WarangalChIJPSaKyOlFMzoRIpR1le1MWYUuhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJPSaKyOlFMzoRIpR1le1MWYU&entry=wimt_gmm_explore �
City Grand HotelChIJPzIW9QtFMzoRVKrp1TrhXS8uhttps://www.google.com/maps/search/?api=1&query=%20&query_place_id=ChIJPzIW9QtFMzoRVKrp1TrhXS8&entry=wimt_gmm_explore "@https://storage.googleapis.com/wimt/events/thumbnails/hotels.png("Ghttps://storage.googleapis.com/wimt/explore/images/explore_warangal.pngv1war_v1 (�