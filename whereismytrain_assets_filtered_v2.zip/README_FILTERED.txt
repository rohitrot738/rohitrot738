Where is My Train APK - filtered assets

This archive contains the APK assets except Hindi station/train information and train-number/name lookup tables.

Removed files: assets/local/station_info_hi, assets/local/station_aka_info_hi, assets/local/train_info_hi.
Removed database tables:
- whereismytrain.db: train_info, train_info_local, train_aka_info, train_aka_info_local
- schedule.db: TripName (train display names)
- userData.db: train_history (contains train_no and train_name)
- alarm.db: locationalarm (contains train_no)

All other assets and database tables are retained. Internal schedule trip IDs are retained as relational keys so schedule/route data remains usable; they are not converted into train numbers or names.
